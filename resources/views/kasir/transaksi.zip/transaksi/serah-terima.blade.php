@extends('layouts.app')

@section('title', 'Serah Terima Kendaraan')
@section('page-title', 'Serah Terima Kendaraan')
@section('breadcrumb', 'Kasir / Transaksi / Serah Terima')

@section('sidebar-nav')
    @include('components.sidebar-kasir')
@endsection

@section('content')
<div class="max-w-3xl mx-auto space-y-5">

    {{-- Info Booking --}}
    <div class="card p-5">
        <h3 class="font-bold text-slate-700 mb-4 flex items-center gap-2">
            <i data-lucide="calendar-check" class="w-5 h-5 text-primary-600"></i> Informasi Booking
        </h3>
        <div class="grid grid-cols-2 gap-x-8 gap-y-2 text-sm">
            @foreach([
                ['Kode Booking',  $booking->kode_booking],
                ['Pelanggan',     $booking->pelanggan->user->name],
                ['No. Telepon',   $booking->pelanggan->user->phone],
                ['Kendaraan',     $booking->kendaraan->nama.' ('.$booking->kendaraan->plat_nomor.')'],
                ['Kategori',      $booking->kendaraan->kategori->nama ?? '-'],
                ['Transmisi',     ucfirst($booking->kendaraan->transmisi)],
                ['Tanggal Mulai', $booking->tanggal_mulai?->format('d M Y')],
                ['Tanggal Selesai',$booking->tanggal_selesai?->format('d M Y')],
                ['Durasi',        $booking->durasi_hari.' hari'],
                ['Estimasi Biaya','Rp '.number_format($booking->estimasi_biaya,0,',','.')],
            ] as [$lbl,$val])
            <div class="flex justify-between py-1.5 border-b border-slate-50">
                <span class="text-slate-400">{{ $lbl }}</span>
                <span class="font-medium text-slate-700 text-right">{{ $val }}</span>
            </div>
            @endforeach
        </div>
    </div>

    {{-- Form Serah Terima --}}
    <div class="card p-5">
        <h3 class="font-bold text-slate-700 mb-4 flex items-center gap-2">
            <i data-lucide="clipboard-list" class="w-5 h-5 text-primary-600"></i> Form Serah Terima
        </h3>
        <form method="POST" action="{{ route('kasir.transaksi.proses-serah-terima', $booking) }}" enctype="multipart/form-data">
            @csrf
            <div class="grid grid-cols-2 gap-4">

                <div>
                    <label class="form-label">Tanggal Pengambilan Aktual</label>
                    <input type="date" name="tanggal_ambil_aktual" value="{{ old('tanggal_ambil_aktual', date('Y-m-d')) }}" class="form-input" required>
                </div>

                <div>
                    <label class="form-label">Kondisi Bahan Bakar</label>
                    <select name="bahan_bakar_awal" class="form-input" required>
                        @foreach(['penuh'=>'Full (F)','3/4'=>'3/4','1/2'=>'1/2','1/4'=>'1/4','kosong'=>'Empty (E)'] as $val=>$lbl)
                        <option value="{{ $val }}">{{ $lbl }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="form-label">KM Odometer Awal</label>
                    <input type="number" name="km_odometer_awal" value="{{ old('km_odometer_awal') }}" class="form-input" required min="0" placeholder="Contoh: 15000">
                </div>

                @php
                    // Mengambil nilai nominal_deposit dari data booking sebagai acuan awal jaminan
                    $depositAwal = $booking->nominal_deposit ?? 0;
                @endphp

                <div>
                    <label class="form-label font-semibold text-slate-700">Uang Jaminan (Deposit)</label>
                    <div class="relative rounded-md shadow-sm">
                        <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <span class="text-slate-400 text-sm">Rp</span>
                        </div>
                        <input type="number" 
                               name="jumlah_deposit" 
                               id="jumlah_deposit"
                               value="{{ old('jumlah_deposit', $depositAwal) }}" 
                               class="form-input pl-9 font-semibold text-green-700 bg-emerald-50/20 focus:bg-white" 
                               min="0" 
                               step="1000"
                               placeholder="Tentukan nominal jaminan...">
                    </div>
                    @if($depositAwal > 0)
                        <p class="text-[11px] text-slate-400 mt-1 italic">
                            * Rekomendasi awal dari booking: <strong>Rp {{ number_format($depositAwal, 0, ',', '.') }}</strong> (Bisa diedit/ditambah).
                        </p>
                    @else
                        <p class="text-[11px] text-slate-400 mt-1">
                            Isi jika kasir ingin menerapkan wajib deposit di tempat.
                        </p>
                    @endif
                </div>

                <div class="col-span-2">
                    <label class="form-label">Foto Kondisi Kendaraan</label>
                    <input type="file" name="foto_kondisi" accept="image/*" class="form-input">
                    <p class="text-xs text-slate-400 mt-1">Foto kendaraan sebelum diserahkan (opsional)</p>
                </div>

                <div class="col-span-2">
                    <label class="form-label">Catatan Kondisi</label>
                    <textarea name="catatan_kondisi" rows="2" class="form-input" placeholder="Catatan kondisi kendaraan saat penyerahan...">{{ old('catatan_kondisi') }}</textarea>
                </div>

                <div class="col-span-2 border-t border-slate-100 pt-4">
                    <h4 class="font-semibold text-slate-700 mb-3 text-sm">Pembayaran Awal (Opsional)</h4>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Metode Pembayaran</label>
                            <select name="metode_pembayaran_id" class="form-input" required>
                                @foreach($metode as $m)
                                <option value="{{ $m->id }}">{{ $m->nama }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label class="form-label">Jumlah Bayar (Rp)</label>
                            <input type="number" 
                                   name="jumlah_bayar" 
                                   id="jumlah_bayar" 
                                   value="{{ old('jumlah_bayar', 0) }}" 
                                   class="form-input font-bold text-slate-800 bg-slate-50" 
                                   min="0" 
                                   step="1000">
                        </div>
                    </div>
                </div>

                <div class="col-span-2">
                    <label class="form-label">Catatan Kasir</label>
                    <textarea name="catatan_kasir" rows="2" class="form-input" placeholder="Catatan kasir...">{{ old('catatan_kasir') }}</textarea>
                </div>
            </div>

            <div class="flex gap-3 mt-5 pt-4 border-t border-slate-100">
                <button type="submit" class="btn-primary flex items-center gap-2">
                    <i data-lucide="check-circle" class="w-4 h-4"></i> Konfirmasi Serah Terima
                </button>
                <a href="{{ route('kasir.booking.index') }}" class="btn-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>

{{-- SCRIPT JAVASCRIPT UNTUK OTOMATISASI HITUNG --}}
{{-- SCRIPT JAVASCRIPT UNTUK OTOMATISASI HITUNG (VERSI AMAN / BEBAS ERROR) --}}
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Mengamankan nilai estimasi biaya dari PHP, konversi langsung ke float di JS
        // Menggunakan json_encode agar aman jika datanya null atau bermasalah
        const estimasiBiaya = Number({!! json_encode($booking->estimasi_biaya ?? 0) !!}) || 0;
        
        const inputDeposit = document.getElementById('jumlah_deposit');
        const inputJumlahBayar = document.getElementById('jumlah_bayar');

        // Pastikan element input benar-benar ditemukan di DOM sebelum diproses
        if (inputDeposit && inputJumlahBayar) {
            function hitungTotalPembayaran() {
                // Ambil nilai deposit, hapus spasi jika ada, konversi ke angka murni
                let nilaiDeposit = inputDeposit.value.trim();
                
                // Jika input kosong atau bukan angka, set menjadi 0
                let nominalDeposit = parseFloat(nilaiDeposit);
                if (isNaN(nominalDeposit) || nominalDeposit < 0) {
                    nominalDeposit = 0;
                }
                
                // Hitung total akumulasi otomatis
                const totalBayarOtomatis = estimasiBiaya + nominalDeposit;
                
                // Masukkan hasil ke dalam form input jumlah_bayar
                inputJumlahBayar.value = totalBayarOtomatis;
            }

            // Jalankan fungsi saat pertama kali halaman terbuka (Load awal)
            hitungTotalPembayaran();

            // Jalankan fungsi setiap kali kasir mengetik atau mengubah nominal deposit
            inputDeposit.addEventListener('input', hitungTotalPembayaran);
            inputDeposit.addEventListener('change', hitungTotalPembayaran);
        } else {
            console.error('Kritikal: Elemen input_deposit atau jumlah_bayar tidak ditemukan di halaman.');
        }
    });
</script>
@endsection