@extends('layouts.app')

@section('title', 'Proses Pengembalian')
@section('page-title', 'Proses Pengembalian Kendaraan')
@section('breadcrumb', 'Kasir / Transaksi / Pengembalian')

@section('sidebar-nav')
    @include('components.sidebar-kasir')
@endsection

@section('content')

@vite('resources/js/transaksi/pengembalian.js')

<div class="max-w-3xl mx-auto space-y-5">

    @php
        // Status pembayaran sewa (pembayaran pertama = pelunasan sewa)
        $pembayaranSewa = $transaksi->pembayaran
            ->where('status', 'lunas')
            ->sortBy('created_at')
            ->first();
        $sewaSudahLunas = $pembayaranSewa !== null;

        // Deposit yang masih ditahan
        $jumlahDeposit  = $transaksi->deposit?->jumlah ?? 0;

        // Keterlambatan
        $batasKembali   = $transaksi->booking->tanggal_selesai;
        $sekarang       = now();
        $telat          = $sekarang->gt($batasKembali);
        $hariTelat      = $telat ? (int) $sekarang->diffInDays($batasKembali) : 0;
    @endphp

    {{-- ================================================================== --}}
    {{-- INFO TRANSAKSI                                                     --}}
    {{-- ================================================================== --}}
    <div class="card p-5">
        <h3 class="font-bold text-slate-700 mb-4 flex items-center gap-2">
            <i data-lucide="receipt-text" class="w-5 h-5 text-primary-600"></i> Informasi Transaksi
        </h3>

        <div class="grid grid-cols-2 gap-x-8 gap-y-2 text-sm">
            @foreach([
                ['Kode Transaksi',   $transaksi->kode_transaksi],
                ['Pelanggan',        $transaksi->booking->pelanggan->user->name],
                ['Kendaraan',        $transaksi->booking->kendaraan->nama.' ('.$transaksi->booking->kendaraan->plat_nomor.')'],
                ['Tgl Pengambilan',  $transaksi->tanggal_ambil_aktual?->format('d M Y')],
                ['Tgl Kembali Plan', $batasKembali?->format('d M Y')],
                ['Total Biaya Sewa', 'Rp '.number_format($transaksi->total_biaya, 0, ',', '.')],
                ['Deposit Ditahan',  'Rp '.number_format($jumlahDeposit, 0, ',', '.')],
            ] as [$lbl, $val])
            <div class="flex justify-between py-1.5 border-b border-slate-50">
                <span class="text-slate-400">{{ $lbl }}</span>
                <span class="font-medium text-slate-700">{{ $val }}</span>
            </div>
            @endforeach

            <div class="flex justify-between py-1.5 border-b border-slate-50 col-span-2">
                <span class="text-slate-400">Status Pembayaran Sewa</span>
                @if($sewaSudahLunas)
                    <span class="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                        <i data-lucide="circle-check-big" class="w-4 h-4"></i> LUNAS
                        <span class="font-normal text-slate-400 ml-1">
                            (dibayar {{ $pembayaranSewa->created_at->format('d M Y') }} via {{ $pembayaranSewa->metodePembayaran->nama }})
                        </span>
                    </span>
                @else
                    <span class="inline-flex items-center gap-1 text-red-600 font-semibold">
                        <i data-lucide="circle-x" class="w-4 h-4"></i> BELUM LUNAS
                    </span>
                @endif
            </div>
        </div>

        @if($telat)
        <div class="mt-3 flex items-start gap-3 bg-red-50 border border-red-200 px-4 py-3 rounded-xl text-sm text-red-700">
            <i data-lucide="triangle-alert" class="w-5 h-5 shrink-0 mt-0.5"></i>
            <div>
                <p class="font-bold text-red-800">Kendaraan TERLAMBAT dikembalikan!</p>
                <p class="mt-0.5">
                    Batas kembali: <strong>{{ $batasKembali->format('d M Y') }}</strong> &mdash; Hari ini: <strong>{{ $sekarang->format('d M Y') }}</strong><br>
                    Selisih keterlambatan: <strong>{{ $hariTelat }} hari</strong>. Pastikan denda keterlambatan dikenakan di bawah.
                </p>
            </div>
        </div>
        @else
        <div class="mt-3 flex items-center gap-2 bg-emerald-50 border border-emerald-200 px-4 py-2.5 rounded-xl text-sm text-emerald-700 font-medium">
            <i data-lucide="circle-check-big" class="w-4 h-4 shrink-0"></i> Pengembalian tepat waktu. Batas: {{ $batasKembali->format('d M Y') }}.
        </div>
        @endif
    </div>

    {{-- ================================================================== --}}
    {{-- FORM PENGEMBALIAN                                                  --}}
    {{-- ================================================================== --}}


    <form method="POST" action="{{ route('kasir.transaksi.proses-pengembalian', $transaksi) }}" enctype="multipart/form-data" id="form-pengembalian">
    @csrf

    {{-- Element Penampung Data untuk dibaca JavaScript (diperbarui tanpa old potongan_deposit) --}}
    <div id="pengembalian-data" 
        class="hidden"
        data-old-dendas="{{ json_encode(old('dendas', [])) }}"
        data-hari-telat="{{ $hariTelat }}"
        data-telat="{{ $telat ? 'true' : 'false' }}"
        data-jumlah-deposit="{{ $jumlahDeposit }}">
    </div>

    <div class="space-y-5">
        {{-- [BAGIAN FORM KONDISI KENDARAAN KEMBALI TETAP SAMA SEPERTI MILIK ANDA] --}}
        <div class="card p-5">
            <h3 class="font-semibold text-slate-700 mb-4 text-sm">Kondisi Kendaraan Kembali</h3>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Tanggal Kembali Aktual</label>
                    <input type="date" name="tanggal_kembali_aktual" value="{{ old('tanggal_kembali_aktual', date('Y-m-d')) }}" class="form-input" required>
                </div>
                <div>
                    <label class="form-label">Kondisi Bahan Bakar</label>
                    <select name="bahan_bakar_akhir" class="form-input" required>
                        @foreach(['penuh' => 'Full (F)', '3/4' => '3/4', '1/2' => '1/2', '1/4' => '1/4', 'kosong' => 'Empty (E)'] as $val => $lbl)
                        <option value="{{ $val }}">{{ $lbl }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="form-label">KM Odometer Akhir</label>
                    <input type="number" name="km_odometer_akhir" value="{{ old('km_odometer_akhir') }}" class="form-input" required min="0" placeholder="Contoh: 16500">
                </div>
                <div>
                    <label class="form-label">Foto Kondisi Kembali</label>
                    <input type="file" name="foto_kondisi_akhir" accept="image/*" class="form-input">
                </div>
                <div class="col-span-2">
                    <label class="form-label">Catatan Kondisi</label>
                    <textarea name="catatan_kondisi_akhir" rows="2" class="form-input" placeholder="Kerusakan, goresan, dll...">{{ old('catatan_kondisi_akhir') }}</textarea>
                </div>
            </div>
        </div>

        {{-- [BAGIAN FORM INPUT DENDA DINAMIS TETAP SAMA SEPERTI MILIK ANDA] --}}
        <div class="card p-5">
            <div class="flex items-center justify-between mb-4">
                <h3 class="font-semibold text-slate-700 text-sm">Denda (jika ada)</h3>
                <button type="button" id="btn-tambah-denda" class="inline-flex items-center gap-1 text-xs font-semibold text-primary-600 hover:underline">
                    <i data-lucide="plus-circle" class="w-3.5 h-3.5"></i> Tambah Denda
                </button>
            </div>
            <div id="denda-container" class="space-y-4"></div>
            <div id="denda-kosong-info" class="text-sm text-slate-400 italic text-center py-4">
                Tidak ada denda. Klik "Tambah Denda" jika ada pelanggaran.
            </div>
            <div id="subtotal-denda-box" class="mt-4 hidden justify-between items-center bg-amber-50 border border-amber-200 px-4 py-2.5 rounded-xl text-sm font-semibold text-amber-800">
                <span>Total Seluruh Denda</span>
                <span id="text-total-denda">Rp 0</span>
            </div>
        </div>

        {{-- REKAPITULASI DEPOSIT (VERSI BARU: ALASAN MANUAL & POTONGAN OTOMATIS) --}}
        <div class="card p-5">
            <h3 class="font-semibold text-slate-700 mb-4 text-sm flex items-center gap-2">
                <i data-lucide="shield-check" class="w-4 h-4 text-amber-500"></i> Rekapitulasi Pengembalian Deposit
            </h3>
            
            <div class="space-y-4 text-sm">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl">
                    <div class="flex justify-between items-center py-1">
                        <span class="text-slate-500">Deposit Awal Ditahan:</span>
                        <strong class="text-slate-800" id="text-deposit-ditahan">
                            Rp {{ number_format($jumlahDeposit, 0, ',', '.') }}
                        </strong>
                    </div>
                    <div class="flex justify-between items-center py-1 border-t border-slate-200/60 md:border-none md:pt-1 pt-2">
                        <span class="text-slate-500">Potongan untuk Denda (Otomatis):</span>
                        <strong class="text-red-600" id="text-deposit-terpotong">
                            Rp 0
                        </strong>
                    </div>
                </div>

                {{-- Form Alasan Dipertahankan Kasir untuk Memperjelas Histori Audit --}}
                <div>
                    <label class="form-label font-medium text-slate-600 mb-1 block">Alasan Potongan / Catatan Detail Kerusakan</label>
                    <input type="text" 
                           name="alasan_potongan" 
                           value="{{ old('alasan_potongan') }}" 
                           class="form-input w-full" 
                           placeholder="Contoh: Potongan otomatis denda keterlambatan / lampu kiri pecah...">
                </div>

                <div class="bg-emerald-50 border border-emerald-200 px-4 py-3 rounded-xl flex justify-between items-center">
                    <span class="text-emerald-700 font-medium">Sisa Saku Deposit Dikembalikan Ke Pelanggan</span>
                    <strong class="text-emerald-800 text-base" id="text-deposit-kembali">
                        Rp {{ number_format($jumlahDeposit, 0, ',', '.') }}
                    </strong>
                </div>
            </div>
        </div>

        {{-- RINGKASAN TAGIHAN PENGEMBALIAN --}}
        <div class="card p-5 border-2 border-primary-100 bg-primary-50/30">
            <h3 class="font-semibold text-slate-700 mb-4 text-sm flex items-center gap-2">
                <i data-lucide="calculator" class="w-4 h-4 text-primary-600"></i> Ringkasan Tagihan Pengembalian
            </h3>
            <div class="space-y-2 text-sm">
                <div class="flex justify-between items-center py-1.5 border-b border-slate-100">
                    <span class="text-slate-500 flex items-center gap-1">
                        <i data-lucide="circle-check-big" class="w-3.5 h-3.5 text-emerald-500"></i> Biaya Sewa (sudah lunas)
                    </span>
                    <span class="text-slate-400 line-through">Rp {{ number_format($transaksi->total_biaya, 0, ',', '.') }}</span>
                </div>
                <div class="flex justify-between items-center py-1.5 border-b border-slate-100">
                    <span class="text-slate-500">Total Denda Terpilih</span>
                    <span class="font-medium text-red-600" id="ringkasan-total-denda">+ Rp 0</span>
                </div>
                <div class="flex justify-between items-center py-1.5 border-b border-slate-100">
                    <span class="text-slate-500">Klaim Kas Tercover Uang Deposit</span>
                    <span class="font-medium text-emerald-700" id="ringkasan-potongan-deposit">− Rp 0</span>
                </div>
                <div class="flex justify-between items-center pt-2">
                    <span class="font-bold text-slate-700" id="label-status-bayar">Sisa Kurang Bayar</span>
                    <span class="font-bold text-lg text-red-600" id="text-jumlah-harus-bayar">Rp 0</span>
                </div>
            </div>
        </div>

        {{-- INPUT PEMBAYARAN KASIR --}}
        <div class="card p-5 hidden" id="box-pembayaran-denda">
            <h3 class="font-semibold text-slate-700 mb-4 text-sm">Pembayaran Denda</h3>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Metode Pembayaran</label>
                    <select name="metode_pembayaran_id" id="select-metode-pembayaran" class="form-input">
                        @foreach($metode as $m)
                        <option value="{{ $m->id }}">{{ $m->nama }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="form-label">Jumlah Bayar (Rp)</label>
                    <input type="number" name="jumlah_bayar" id="input-jumlah-bayar" value="0" class="form-input" min="0" step="1000">
                    <p class="text-xs text-slate-400 mt-1">Sisa kekurangan denda yang wajib dilunasi penyewa.</p>
                </div>
            </div>
        </div>

        {{-- BOX INFO KONDISI IMPAS --}}
        <div class="card p-4 border border-emerald-200 bg-emerald-50" id="box-info-impas">
            <div class="flex items-center gap-2 text-sm text-emerald-700 font-medium">
                <i data-lucide="circle-check-big" class="w-4 h-4"></i>
                <span id="text-info-impas">Selesai aman tanpa tagihan denda baru.</span>
            </div>
            <input type="hidden" name="jumlah_bayar" id="hidden-jumlah-bayar" value="0">
        </div>
    </div>

    <div class="flex gap-3 mt-5">
        <button type="submit" class="btn-primary flex items-center gap-2" onclick="return confirm('Konfirmasi pengembalian kendaraan ini?')">
            <i data-lucide="check-circle" class="w-4 h-4"></i> Selesaikan Pengembalian
        </button>
        <a href="{{ route('kasir.transaksi.show', $transaksi) }}" class="btn-secondary">Batal</a>
    </div>
</form>

</div>

@endsection